<?php

/**
 * Hero Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'uofi-card-deck-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'uofi uofi-card-deck';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and assign defaults.
$width = get_field('width') ?: 350;
$image = get_field('image') ?:  get_template_directory_uri() . '/template-parts/blocks/card/your-image-goes-here.jpg' ;
$title = get_field('title') ?: null;
$text = get_field('text') ?: null;

$allowed_blocks = array('acf/uofi-card-block' );

$template =
array(
    array( 'acf/uofi-card-block')	
		);

?>
<div class="uofi uofi-card-deck">
<InnerBlocks allowedBlocks="<?= esc_attr( wp_json_encode( $allowed_blocks ) ) ?>" template="<?= esc_attr( wp_json_encode( $template ) ) ?>" />
</div>
<style type="text/css">
	<?php
	//If the public view, not admin
	if( !is_admin() )
	{
	?>
		.uofi-card-deck
			{
			display: flex;
			flex-wrap: wrap;
			justify-content: space-evenly;
			}
		.uofi-card-deck .uofi-card
			{
			width: <?= $width ?>px !important;
			}
	<?php
	}
	else
	{
	?>
	.uofi-card-deck
		{
		display: block !important;
		}
				
	.uofi-card-deck	.uofi-card
		{
		width: auto !important;
		}

	.uofi-card-deck .block-editor-block-list__layout>div
		{
		width: <?= $width ?>px !important;
		}
	<?php
	}
	?>	
</style>













