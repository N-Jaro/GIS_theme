jQuery(document).ready(function ($) {
	
	// add or remove isattop class on scroll
	$(window).scroll(function () {
		if ($(window).scrollTop() > 150) {
			$("body").removeClass("isattop");
		}
		else {
			$("body").addClass("isattop");
		}

		/* progress bar */
		var scrollBarWidth = $(window).scrollTop() / ($("body").height() - $(window).height()) * 100;
		$("body.scrollbar #scrollbar").css("width", scrollBarWidth + '%');



		/* goto top button */
		if ($(window).scrollTop() > 500) {
			$("#gototop").removeClass("hidden");
		}

		if ($(window).scrollTop() < 500) {
			$("#gototop").addClass("hidden");
		}



	});

	$("#gototop").click(function (e) { $("html, body").animate({ scrollTop: "0" });});

	/* Fix to allow "infinite" depth WP menus */
	
	$('.dropdown-menu > li > .dropdown-menu').parent().addClass('dropdown-submenu').find(' > .dropdown-item').attr('href', 'javascript:;').addClass('dropdown-toggle');
	$('.dropdown-submenu > a').on("click", function(e) {
	var dropdown = $(this).parent().find(' > .show');
		$('.dropdown-submenu .dropdown-menu').not(dropdown).removeClass('show');
		$(this).next('.dropdown-menu').toggleClass('show');
		e.stopPropagation();
	});
	$('.dropdown').on("hidden.bs.dropdown", function() {
		$('.dropdown-menu.show').removeClass('show');
	});
	

});