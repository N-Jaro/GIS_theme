<?php
/**
 * University of Illinois 2020 Theme Customizer
 *
 * @package University_of_Illinois_2020
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function uofi_2020_customize_register( $wp_customize ) {
	$wp_customize->remove_section('header_image');
	$wp_customize->remove_panel('nav_menus');
	$wp_customize->remove_panel('widgets');
	$wp_customize->remove_section('custom_css');
	$wp_customize->remove_section('colors');
	$wp_customize->remove_section('background_image');
	$wp_customize->remove_section('static_front_page');
	$wp_customize->remove_section('title_tagline');

  $wp_customize->add_section( 'uofi2020_settings_section',
    array(
        'title'         => __( 'Customizing UofI 2020', 'uofi2020' ),
        'description'   => __( '<p>The UofI 2020 Theme specific settings can be customized using the <a href="' . get_site_url(get_current_blog_id(),"wp-admin/admin.php?page=theme-general-settings") . '"><b>Theme Settings</b></a> item on your WordPress dashboard. <p><p>Other settings you might normally access here (like setting the home page, etc.) can be found in the Dashboard Settings <a href="' . get_site_url(get_current_blog_id(),"wp-admin/options-general.php") . '"><b>WordPress General Settings</b></a> or <a href="' . get_site_url(get_current_blog_id(),"wp-admin/options-reading.php") . '"><b>WordPress Reading Settings</b></a> </p>' ),
        'priority'      => 1,   
    ) 
	);

$wp_customize->add_setting( 'uofi2020_goto_settings',
    array(
        'transport'         => 'refresh',
    )
);      

//we must have a control in a section in a panel if we want to display the section	
$wp_customize->add_control( 'uofi2020_goto_settings', 
    array(
        'type'        => 'hidden',
        'priority'    => 10,
        'section'     => 'uofi2020_settings_section',
    ) 
	);
}
add_action( 'customize_register', 'uofi_2020_customize_register',50 );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function uofi_2020_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function uofi_2020_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function uofi_2020_customize_preview_js() {
	wp_enqueue_script( 'uofi-2020-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'uofi_2020_customize_preview_js' );
