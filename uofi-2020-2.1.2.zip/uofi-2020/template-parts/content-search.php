<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package University_of_Illinois_2020
 */

?>
<?php
$suppress_sidebar_this_page =  get_field('suppress_page_title') ? get_field('suppress_page_title') : false; //Advanced Custom Fields function, get_field() 
$hide_title =  $suppress_sidebar_this_page ? 'screen-reader-text' : '';
$featured_image_settings =  get_field('featured_image_options') ? get_field('featured_image_options') : null; // Advanced Custom Fields function, get_field()
	if($featured_image_settings)
	{
	$featured_image_display = $featured_image_settings['display_style'] ? $featured_image_settings['display_style'] : 'page' ;
	}
	else
	{
	$featured_image_display ='page' ;
	}

$max_width = "870";

	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
	$show_sidebar = $suppress_sidebar_site_wide;
	if($show_sidebar_this_page != 0) 
		{
		$show_sidebar = $show_sidebar_this_page - 1;
		}
		
if (!$show_sidebar)
	{
	$max_width = "1200";	
	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header il-formatted">
		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

		<?php if ( 'post' === get_post_type() ) : ?>
		<div class="entry-meta">
			<?php
			uofi_2020_posted_on();
			uofi_2020_posted_by();
			?>
		</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->

	<?php uofi_2020_post_thumbnail(); ?>

	<div class="entry-summary">
		<?php the_excerpt(); ?>
	</div><!-- .entry-summary -->

	<footer class="entry-footer">
		<?php uofi_2020_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
