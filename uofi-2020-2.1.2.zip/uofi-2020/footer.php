<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package University_of_Illinois_2020
 */

?>
<?php
	//Gather site/page variables
	$footer = 						get_field('footer_contents', 'option'); //Advanced Custom Fields function, get_field()
	
	// This is an optional override to using the Site title for the footer that we decided we likely won't use, but leaving this here for now in case we change our mind
	/*$unit_name = 				$footer['address']['unit_name'] ? $footer['address']['unit_name'] : null ; */ /* string */ 
	/* $link_for_unit_name =	$footer['address']['link_for_unit_name'] ? $footer['address']['link_for_unit_name'] : null ;  */  /* link_for_unit_name */
	/* $unit_name_link =			$unit_name ? ($link_for_unit_name ? '<a href="'. $link_for_unit_name .'">'. $unit_name .'</a>' : $unit_name) : null;  */  
	
		
	$unit_name_link	 =		'<a href="' . get_home_url() . '">' . get_bloginfo( 'name' ) . '</a>';
	
	if($footer)
		{
		$address_line_one = 		$footer['address']['address_line_one'] ? $footer['address']['address_line_one'] : null ; /* string */
		$address_line_two =		$footer['address']['address_line_two'] ? $footer['address']['address_line_two'] : null; /* string */
		$city =								$footer['address']['city'] ? $footer['address']['city'] : null; /* string */
		if(trim($city) === '') 		{$city = null;}
		$state =							$footer['address']['state'] ? $footer['address']['state'] : null; /* string */
		$zip =								$footer['address']['zip'] ? $footer['address']['zip'] : null; /* string */
		$email_address =			$footer['address']['email_address'] ? $footer['address']['email_address'] : null; /* string */
		$phone =						$footer['address']['phone'] ? $footer['address']['phone'] : null; /* string */
		}
	else
		{
		$address_line_one =		null ; /* string */
		$address_line_two =		null; /* string */
		$city =								null; /* string */
		$state =							null; /* string */
		$zip =								null; /* string */
		$email_address = 			null;		
		}
	
	$address =  		 			null;	
		if( !empty($city) | !empty($state) | !empty($zip) | !empty($address_line_one) | !empty($address_line_two) )
		{
		$address = '';
		$address .= $address_line_one ? '<p>' . $address_line_one . '</p>' : '';
		$address .= $address_line_two ? '<p>' . $address_line_two . '</p>' : '';
		if( !empty($city) | !empty($state) | !empty($zip) )
			{
			$address .= '<p>';	
			$address .= $city ? $city . ', ' : '';
			$address .= $state ? $state . ', ' : '';
			$address .= $zip ? $zip : '';
			$address .= '</p>';
			}
		if($phone)
			{
			$address .= '<p>' . $phone . '<p>';		
			}
		if($email_address)
			{
			$address .= '<p>Email: <a href="mailto:' . $email_address . '">' . $email_address . '</a><p>';		
			}
		}

	$footer_sections = null;
	$social_media = null;
	$related = null;
		
	if($footer)
		{
		$email_address =		$footer['address']['email_address'] ? $footer['address']['email_address'] : null; /* string */
		$footer_sections =		$footer['footer_sections'] ? $footer['footer_sections'] : null; /* array, contains elements: $footer_sections[i]["footer_section"] . footer_section is WYSIWYG HTML content*/
		$social_media =			$footer['social_media'] ? $footer['social_media'] : null;
		$related =					$footer['related'] ? $footer['related'] : null;
		}


	$secondary_site_title_group = get_field('secondary_site_title_group', 'option') ? get_field('secondary_site_title_group', 'option') : null;

	$secondary_site_title_text = null;
	$secondary_site_title_link = null;

	if($secondary_site_title_group)
		{
		$secondary_site_title_text = $secondary_site_title_group['secondary_site_title'] ? $secondary_site_title_group['secondary_site_title'] : null;
		$secondary_site_title_link = $secondary_site_title_group['secondary_site_link'] ? $secondary_site_title_group['secondary_site_link'] : null;	
		}
		
	$secondary_site_title = null;
		if( $secondary_site_title_link )
			{
			$secondary_site_title = '<a href="' . $secondary_site_title_link . '">' . $secondary_site_title_text . '</a>';
			}
		else
			{
			$secondary_site_title = $secondary_site_title_text;
			}
	
	if($footer)
		{
		$show_log_in_link =  !$footer['sub_footer_links']['show_log_in_link'] ? $footer['sub_footer_links']['show_log_in_link'] : true ;
		$sub_footer_links = $footer['sub_footer_links']['sub_footer_links'] ? $footer['sub_footer_links']['sub_footer_links'] : null ; /* Associative array, [title, url] */
		}
	else
		{
		$show_log_in_link = false ; 
		$sub_footer_links = null ; /* Associative array, [title, url] */
		}

	$secondary_site_title_group = get_field('secondary_site_title_group', 'option') ? get_field('secondary_site_title_group', 'option') : null;

	$secondary_site_title_text = null;
	$secondary_site_title_link = null;

	if($secondary_site_title_group)
		{
		$secondary_site_title_text = $secondary_site_title_group['secondary_site_title'] ? $secondary_site_title_group['secondary_site_title'] : null;
		$secondary_site_title_link = $secondary_site_title_group['secondary_site_link'] ? $secondary_site_title_group['secondary_site_link'] : null;	
		}
		
	$secondary_site_title = null;
		if( $secondary_site_title_link )
			{
			$secondary_site_title = '<a href="' . $secondary_site_title_link . '">' . $secondary_site_title_text . '</a>';
			}
		else
			{
			$secondary_site_title = $secondary_site_title_text;
			}	
?>
	</div>

	<footer id="colophon" class="site-footer">
	   <il-footer>

	  <div slot="contact" class="il-footer-contact uofi_address">
		<?php if ( $unit_name_link ) { ?>
			<p><?= $unit_name_link ?></p><?="\r\n" ?>
		<?php } ?>
		<?php if ( $address ) { ?>
			<?= $address . "\r\n" ?>
		<?php } ?>
	  </div>

		<?php if ( $social_media )  { ?>
			<div slot="social" class="il-footer-social">
				<ul>
				<?php 
				foreach ($social_media as $link)
					{
					?>
							<li><a href="<?= $link['link']['url'] ?>"><?= $link['link']['title'] ?></a></li>
					<?php
					}
					?>
				</ul>
		  </div>
		<?php } ?>

		<?php if ( $related || $secondary_site_title )  { ?>
		<div slot="parent" class="il-footer-parent">
			<?php if ($secondary_site_title )  { ?>
				<p><?=$secondary_site_title?></p>
			<?php } ?>
			<?php if ( $related )  { ?>
				<?php  foreach ( $related as $account )  { ?>
					<p><a href="<?= $account['link']['url'] ?>"><?= $account['link']['title'] ?></a></p>
				<?php } ?>
			<?php } ?>
		</div>
		<?php } ?>

		<?php if ( $footer_sections )
		{ 
		if ( count($footer_sections) === 1 )
			{
			?>
			<div class="il-footer-navigation">
				<?php
				if ( $footer_sections[0]['navigation_section_or_freeform_section'] !== 'navigation' )
					{
					echo($footer_sections[0]['footer_section']);
					}
				else
					{
					?>
					<nav aria-labelledby="footer-nav-1">
					<h2 id="footer-nav-1"><?= $footer_sections[0]['nav_title'] ?></h2>
					<ul>
					<?php
					foreach ( $footer_sections[0]['links'] as $link )
					{
					?>
						<li><a href="<?= $link['link']['url'] ?>"><?= $link['link']['title'] ?></a></li>
					<?php
					}
					?>
					</ul>			
					</nav>
					<?php
					}
				?>
			</div>
			<?php
			} 
		elseif ( count($footer_sections) > 1 )
			{
			?>
			<div class="il-footer-navigation">
				<?php
				$counter = 0;
				foreach ( $footer_sections as $footer_section )
					{
					$counter++;
				?>
					<div class="il-footer-navigation-column">
				<?php
				if ( $footer_section['navigation_section_or_freeform_section'] !== 'navigation' )
					{
					echo($footer_section['footer_section']);
					}
				else
					{
					?>
					<nav aria-labelledby="footer-nav-<?= $counter ?>">
					<h2 id="footer-nav-<?= $counter ?>"><?= $footer_section['nav_title'] ?></h2>
						<ul>
							<?php
							foreach ( $footer_section['links'] as $link )
							{
							?>
								<li><a href="<?= $link['link']['url'] ?>"><?= $link['link']['title'] ?></a></li>
							<?php
							}
							?>
						</ul>			
					</nav>
					<?php
					}
					?>				
					</div>
				<?php
					}
				?>
			</div>
			<?php
			}
		}
		?>
		
		  <nav slot="links" class="il-footer-links" aria-label="Legal notices">
			<ul>
			  <li><button data-il="cookies" ></button></li>
			  <li><a data-il="privacy"></a></li>
			  <li><a data-il="copyright"></a></li>
			  <li><a data-il="accessibility"></a></li>
			  <?php
				if( $sub_footer_links && !empty($sub_footer_links) )
				{
				foreach($sub_footer_links as $sub_footer_link)
					{
					?>					
					<li><a href="<?=$sub_footer_link['link']['url']?>"><?=$sub_footer_link['link']['title']?></a></li>
					<?php
					}
				}
				if ( $show_log_in_link )
					{
					?>					
					<li><a href="<?= wp_login_url() ?>">Log In</a></li>
					<?php					
					}
				?>
			</ul>
		  </nav>
		</il-footer>
	</footer><!-- #colophon -->


</div><!-- #page -->

<?php wp_footer(); ?>

<div id="gototop" class="hidden">
	<a href="#"><i class="fa fa-chevron-up"></i><span class="sr-only">Go to top</span></a>
</div>
</body>
</html>
