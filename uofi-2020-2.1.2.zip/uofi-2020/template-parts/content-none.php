<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package University_of_Illinois_2020
 */

?>
<?php
$suppress_sidebar_this_page =  get_field('suppress_page_title') ? get_field('suppress_page_title') : false; //Advanced Custom Fields function, get_field() 
$hide_title =  $suppress_sidebar_this_page ? 'screen-reader-text' : '';
$featured_image_settings =  get_field('featured_image_options') ? get_field('featured_image_options') : null; // Advanced Custom Fields function, get_field()
if($featured_image_settings)
	{
	$featured_image_display = $featured_image_settings['display_style'] ? $featured_image_settings['display_style'] : 'page' ;
	$featured_image_display_height = has_post_thumbnail($post->ID) ? wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false )[1] . 'px' : 'auto' ; 
	}
else
	{
	$featured_image_display = 'left' ; //The default is left for historical reasons. Before the alignment was optional, in version <= 1.1.3, it was always left aligned -rslater 9-14-2021
	}



$max_width = "870";

	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
	$show_sidebar = $suppress_sidebar_site_wide;
	if($show_sidebar_this_page != 0) 
		{
		$show_sidebar = $show_sidebar_this_page - 1;
		}
		
if (!$show_sidebar)
	{
	$max_width = "1200";	
	}

?>
<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'uofi-2020' ); ?></h1>
	</header><!-- .page-header -->

	<article><div class="entry-content"><div class="uofi-default-block">
	<div class="page-content">
		<?php
		if ( is_home() && current_user_can( 'publish_posts' ) ) :

			printf(
				'<p>' . wp_kses(
					/* translators: 1: link to WP admin new post page. */
					__( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'uofi-2020' ),
					array(
						'a' => array(
							'href' => array(),
						),
					)
				) . '</p>',
				esc_url( admin_url( 'post-new.php' ) )
			);

		elseif ( is_search() ) :
			?>

			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'uofi-2020' ); ?></p>
			<?php
			get_search_form();

		else :
			?>

			<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'uofi-2020' ); ?></p>
			<?php
			get_search_form();

		endif;
		?>
	</div><!-- .page-content -->
	</div></div></article>
</section><!-- .no-results -->

