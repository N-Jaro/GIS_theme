jQuery( document ).ready(function($) {
	/*
	setTimeout(function(){
        $(".edit-post-visual-editor").addClass("il-formatted");
	}, 10000);
	setTimeout(function(){
        $(".edit-post-visual-editor").addClass("il-formatted");
	}, 10000);
	setTimeout(function(){
        $(".edit-post-visual-editor").addClass("il-formatted");
	}, 30000);
	*/
	
});