<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package University_of_Illinois_2020
 */

$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
$suppress_sidebar = $suppress_sidebar_site_wide;

if($show_sidebar_this_page != 0) 
	{
	$suppress_sidebar = $show_sidebar_this_page - 1;
	}

if( ! is_archive() && ! is_search() )
	{
	if ( ! is_active_sidebar( 'sidebar-1' ) || ! $suppress_sidebar )
		{
		return;
		}
	}

if( is_archive() || is_search() )
	{
	if ( ! $suppress_sidebar_site_wide )
		{
		return;
		}
	}
?>

<aside id="secondary" class="widget-area il-formatted" aria-label="Document Sidebar">
	<div class="widget_area_wrapper">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div>
</aside><!-- #secondary -->
