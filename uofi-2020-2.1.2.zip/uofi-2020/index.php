<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package University_of_Illinois_2020
 */

get_header();
$extra_classes = '';
if ( is_home() && ! is_front_page() ) 
{
	$extra_classes	= "news_page";
}

	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
	$show_sidebar = $suppress_sidebar_site_wide;
	if($show_sidebar_this_page != 0) 
		{
		$show_sidebar = $show_sidebar_this_page - 1;
		}
?>
	<div id="primary_secondary_wrapper" class="d-flex flex-md-row flex-column justify-content-center <?=$extra_classes?>">
		<main id="primary" class="site-main <?php if (! $show_sidebar) { echo('flex-grow-1'); } ?>" aria-label="Document Content">

		<?php
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) :
				?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>
				<?php
			endif;

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_type() );

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- #main -->
		<?php
		get_sidebar();
		?>
	</div>
<?php
get_footer();
?>
