<?php

/**
 * Hero Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'uofi-hero-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'uofi uofi-hero';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and assign defaults.
$title = get_field('title') ?: null;
	// function_exists('get_current_screen') generally only returns true on admin pages, not preview/view pages, thus we use it to tell "user is editing the content"
	if( !$title && function_exists('get_current_screen') == 1  ) { $title = 'Edit this in Edit Mode <span class="dashicon dashicons dashicons-edit" style="display: inline; vertical-align: -0.05em; font-size: .8em;"></span>  or Block Settings Panel <span style="display: inline-flex"><svg width="0.8em" height="0.8em" style="display:inline-flex; filter: drop-shadow(0.01em 0.01em 0.02em black);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" role="img" aria-hidden="true" focusable="false"><path fill="#FFFFFF" fill-rule="evenodd" d="M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" clip-rule="evenodd"></path></svg></span>';}
$background_option 				= get_field('background_option') ?: null;
$background_image_options = get_field('background_image_options') ?: null;
$background_image 				= null;
$background_image_alt			= null;
if($background_image_options)
	{
	$background_image 			= array_key_exists( 'image', $background_image_options ) ? ( $background_image_options['image'] ?: null ): null;
	$background_image_alt 	= array_key_exists( 'image_description', $background_image_options ) ? ( $background_image_options['image_description'] ?: null ): null;
	}
$background_color 				= get_field('background_color') ?: null;
	$className 						.= " $background_color ";
$content_type 						= get_field('hero_content_type') ?: null;
$content_type							= 'cta'; //Always cta until/unless WIGG Design Group Approves more, rslater, 10-21-21
$h_align					 				= get_field('h_align') ?: null;
$v_align									= get_field('v_align') ?: null;
$call_to_action_content 			= get_field('call_to_action_content') ?: null;			
$cta_text_block						= null;
$cta_text_buttons					= null;
if($call_to_action_content)
	{
	$cta_text_block		 			= array_key_exists( 'text', $call_to_action_content ) ? ( $call_to_action_content['text'] ?: null ): null;
	$cta_text_buttons				= array_key_exists( 'buttons', $call_to_action_content ) ? ( $call_to_action_content['buttons'] ?: null ): null;
	}
$freeform_section 					= get_field('freeform_section') ?: null;

$allowed_blocks = array( 'core/spacer' );

$template =
array(
		array( 'core/spacer',  array(
													'style' => array('height' => '25px'),
													)
				)
		);
?>
<div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?>">
<il-hero <?php if ( $background_option  === 'image' && $background_image ) { ?>background="<?= $background_image['url'] ?>"<?php } ?><?php if ( $h_align && $v_align ) { echo('align="' . $h_align . ' ' . $v_align . '"'); } ?> <?= ($background_color === 'orange' ) ? 'color="orange"' : '' ?><?php ?>>
    <?= ($title) ? '<h1>' . $title . '</h1>': '' ; ?>
	<?php
	if ( $content_type === 'cta' && ( $cta_text_block || $cta_text_buttons ) )
	{
	?>
	<?= ($cta_text_block)? '<div class="cta-text">' . $cta_text_block . '</div>' : '' ?>
		<?php
		if ( $cta_text_buttons && array_key_exists( 'title', $cta_text_buttons[0]['button'] ) )
		{
		?>
		<ul>
		<?php
		foreach( $cta_text_buttons as $button )
		{
		?>
			<li>
				<a href="<?= $button['button']['url'] ?>" <?= ( $button['button']['target'] ) ? 'target="' . $button['button']['target'] . '"' : '' ?>><?= $button['button']['title'] ?></a>
			</li>
		<?php
		}
		?>
		</ul>
		<?php
		}
		?>
	<?php
	}
	elseif ( $content_type === 'freeform'  && $freeform_section)
	{
	echo( '<div class="freeform">' . $freeform_section . '</div>' );
	}
	else
	{
	//This is nice in place documentation, but it prevents the user from having a hero with _just_ a title, since this bit is always output
	/*
	echo( '<div class="freeform"><p>Edit this in Edit Mode  (click this and then the pencil icon above <span class="dashicon dashicons dashicons-edit" style="display:inline-flex; vertical-align: -0.15rem; 0px 0px 1px rgb(0 0 0 / 50%), 0px 0px 2px rgb(0 0 0), 0px 0px 8px rgb(0 0 0), 0px 0px 16px rgb(0 0 0 / 85%), 0px 0px 24px rgb(0 0 0 / 70%);"></span>)  or in the Block Settings Panel (to the right, which can be toggled open with the gear icon <span style="display: inline-flex;"><svg width="0.8em" height="0.8em" style="filter: drop-shadow(0.04em 0.04em 0.08em black);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" role="img" aria-hidden="true" focusable="false"><path fill="#ffffff" fill-rule="evenodd" d="M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" clip-rule="evenodd"></path></svg></span>)</p></div>' );
	*/
	}
	?>
</il-hero>
<?php echo '<InnerBlocks allowedBlocks="' . esc_attr( wp_json_encode( $allowed_blocks ) ) . '" template="' . esc_attr( wp_json_encode( $template ) ) . '" />'; ?>
</div>













