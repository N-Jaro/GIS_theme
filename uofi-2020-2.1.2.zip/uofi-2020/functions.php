<?php
/**
 * University of Illinois 2020 functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package University_of_Illinois_2020
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'uofi_2020_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function uofi_2020_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on University of Illinois 2020, use a find and replace
		 * to change 'uofi-2020' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'uofi-2020', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'navigation' => esc_html__( 'Site Navigation', 'uofi-2020' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'uofi_2020_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'uofi_2020_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function uofi_2020_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'uofi_2020_content_width', 640 );
}
//add_action( 'after_setup_theme', 'uofi_2020_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function uofi_2020_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'uofi-2020' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'uofi-2020' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s" aria-label="Site sidebar">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'uofi_2020_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function uofi_2020_scripts() {
	//Cache-busting version string based on file last mod info approach courtesy of Andrija Naglic. Sweet. Thanks, Andrija!
	$my_css_ver = date("ymd-Gis", filemtime( plugin_dir_path( __FILE__ ) . 'style.css' ));
	
	wp_register_style( 'main-css',  get_stylesheet_uri(), array('bootstrapcss'), $my_css_ver );
	wp_enqueue_style( 'main-css' );

	wp_style_add_data( 'main-css', 'rtl', 'replace' );

	//wp_enqueue_style( 'formatting', get_template_directory_uri() . '/css/formatting.css',array(),null);
	//wp_enqueue_style( 'fonts', get_template_directory_uri() . '/css/fonts.css',array(),null);

	$my_js_ver  = date("ymd-Gis", filemtime( plugin_dir_path( __FILE__ ) . 'js/main.js' ));
	wp_enqueue_script( 'main_js', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), $my_js_ver );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_script( 'skiptoconf', get_template_directory_uri() . '/js/skipto.config.js',array(),null );
	wp_enqueue_script( 'skipto', 'https://cdn.disability.illinois.edu/skipto.min.js',array(),null);
	wp_enqueue_script( 'bootstrapjs', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js',array(),null);
	wp_enqueue_script( 'fontawesome', 'https://kit.fontawesome.com/846f7e331a.js',array(),null);
	wp_enqueue_script( 'popper', 'https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js',array(),null);
		
	if(strcmp( $_SERVER['REMOTE_ADDR'], '127.0.0.1' ) !== 0 && strcmp( $_SERVER['REMOTE_ADDR'], '::1' ) !== 0)	
		{
		wp_enqueue_script( 'onetrust', 'https://onetrust.techservices.illinois.edu/scripttemplates/otSDKStub.js',array(),null);
		}
	wp_enqueue_script( 'toolkit', 'https://cdn.brand.illinois.edu/toolkit/2.3/toolkit.js', array(),null);
	wp_enqueue_style( 'bootstrapcss', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css',array(),null);
}
add_action( 'wp_enqueue_scripts', 'uofi_2020_scripts' );

function uofi2020_block_assets(){

	wp_enqueue_style( 'block-styles', get_template_directory_uri() . '/block-styles.css');
	wp_enqueue_style( 'toolkit','https://cdn.brand.illinois.edu/toolkit/2.3/toolkit.css');
	wp_enqueue_script( 'toolkit', 'https://cdn.brand.illinois.edu/toolkit/2.3/toolkit.js');
}
add_action( 'enqueue_block_assets','uofi2020_block_assets');



/**
 * add attributes to scripts that require them
 */

function uofi_2020_scripts_add_data_attribute($tag, $handle) {
        switch($handle){
                case('bootstrapjs'):
                return str_replace( ' src', ' crossorigin="anonymous" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" src', $tag );
                        break;
                case ('fontawesome'):
                return str_replace( ' src', ' crossorigin="anonymous" src', $tag );
                        break;
                case('popper'):
                return str_replace( ' src', ' crossorigin="anonymous" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" src', $tag );
                        break;
                case('onetrust'):
                return str_replace( ' src', ' data-domain-script="26be7d61-2017-4ea7-8a8b-8f1704889763" src', $tag );
                        break;
                default:
                        return $tag;
        }

}
add_filter('script_loader_tag', 'uofi_2020_scripts_add_data_attribute', 10, 2);

/**
 * add attributes to styles that require them
 */

function uofi_2020_styles_add_data_attribute($tag, $handle) {
        switch($handle){
                case('bootstrapcss'):
                return str_replace( ' href', ' crossorigin="anonymous" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" href', $tag );
                        break;
                default:
                        return $tag;
        }

}
add_filter('style_loader_tag', 'uofi_2020_styles_add_data_attribute', 10, 2);



/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/* End Underscores, Begin Custom Code */

//Check to see if updates for the theme are available and, if they are, notify the admin user_error
function uofi_2020_theme_version_check () {
	if(function_exists('curl_version')) //Check to see if the system running this code allows CURL. Pretty safe bet if this function is defined, you can PHP curl on the system running this. :)
		{
		if(is_child_theme())
		{
			$site_version = wp_get_theme()->parent()->get( 'Version' );
		}
		else
		{
			$site_version = wp_get_theme()->get( 'Version' );
		}
		
		$upstream_version_file = curl_init("https://uofi2020thememeta.s3.us-east-2.amazonaws.com/wptheme_uofi2020_current_version.txt");
		curl_setopt($upstream_version_file, CURLOPT_FOLLOWLOCATION, true); //Since that's a go.illinois URL, we know we need CURL to follow the redirects
		curl_setopt($upstream_version_file, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($upstream_version_file, CURLOPT_TIMEOUT, 3); //If it is taking longer than 3 seconds to get the upstream file, bail, because something is wrong.
		curl_exec($upstream_version_file);
		$upstream_string = curl_exec($upstream_version_file);
		//Make sure the upstream string contains a version string, then assign it if it is to the local variable
		$upstream_version = version_compare( $upstream_string, '0.0.1', '>=' ) >= 1 ? $upstream_string : null; //Nice hack here -- if it isn't greater than 0.0.1 then it isn't a version string at all
		
		$curl_response_code =  curl_getinfo($upstream_version_file, CURLINFO_RESPONSE_CODE);
		curl_close($upstream_version_file);
		
		if($curl_response_code == '200' && $upstream_version) //For instance, if we got a 403 forbidden  response from the server-- or anything other than a 200 OK -- then bail
		{
			if( version_compare($site_version, $upstream_version) < 0  && (  (!is_multisite() && current_user_can( 'update_themes')) || (is_multisite()  && current_user_can( 'setup_network' )))) 
			{
			?>
				<div class="notice notice-warning is-dismissible">
					<div class="theme-update-notice">	
						<div class="theme-update-notice-content">
							<h2>There is a more recent version of your theme <strong>(University of Illinois)</strong> available</h2>
								<p>You are using version <?php echo($site_version)?> of the University of Illinois WordPress theme.</p>

								<div>Version <?php echo($upstream_version) ?> is available. Please 
								<ul style="list-style: disc; margin-left: 2rem;">
									<li>
									<a href="https://go.illinois.edu/uofiwptheme" target="_blank">download version <?php echo($upstream_version) ?> of the University of Illinois theme (U of I login required)</a>
											and then
									</li>
									<li>
									update your theme by Choosing "Upload Theme" from  
											<?php if(!is_multisite()) { ?>
											<a href="<?php echo (site_url().'/wp-admin/theme-install.php?browse=featured' ) ?>">your site's Theme Settings page.</a>
											<?php } else { ?>
											<a href="<?php echo (network_site_url().'/wp-admin/network/theme-install.php?browse=featured' ) ?>">your multisite WordPress network's Theme Settings page</a>
											<?php } ?>
									</li>
								<li>
								Choose the <?php echo($upstream_version) ?> version of the theme you just downloaded for the "Choose File" option  and click "Install Now"
								</li>
								<li>
								When prompted with a warning, "The theme is already installed," click "Replace current with uploaded".
								</li>
								</ul>
								</div>
								<p>If you would like to receive emails when updated versions of this theme are available, please subscribe to illinoiswptheme-updates@lists.illinois.edu by sending an email to <a href="mailto:lists@lists.illinois.edu?subject=subscribe illinoiswptheme-updates">lists@lists.illinois.edu</a> with the subject line as, "subscribe illinoiswptheme-updates" or by providing us with your email address at  <a href="https://lists.illinois.edu/lists/subscribe/illinoiswptheme-updates" target="_blank">https://lists.illinois.edu/lists/subscribe/illinoiswptheme-updates</a>. </p>
						</div>
						<div class="theme-update-notice-image">
							<a href="<?php echo(get_template_directory_uri().'/images/screenshots-for-theme-version-check.gif') ?>"><img style="width:100%; height:auto;" src="<?php echo(get_template_directory_uri().'/images/screenshots-for-theme-version-check.gif') ?>"/></a>
						</div>
					</div>
				</div>
			<?php
			}
		}
		}
}
add_action( 'admin_notices', 'uofi_2020_theme_version_check' );

//Add ACF Pro if the site doesn't already have ACF
	// Define path and URL to the ACF plugin.
	define( 'MY_ACF_PATH', get_template_directory() . '/inc/advanced-custom-fields-pro/' );
	define( 'MY_ACF_URL', get_template_directory_uri() . '/inc/advanced-custom-fields-pro/' );

	// Include the ACF plugin.
	include_once( MY_ACF_PATH . 'acf.php' );

	// Customize the url setting to fix incorrect asset URLs.
	add_filter('acf/settings/url', 'my_acf_settings_url');
	function my_acf_settings_url( $url ) {
		return MY_ACF_URL;
	}

	//Limit the ability to edit field groups to Network Admins on WordPress Multisite Networks
	function my_acf_settings_capability( $path ) {
		if(is_multisite())
			{
			return 'manage_network';
			}
		return 'activate_plugins';
	}

	add_filter('acf/settings/capability', 'my_acf_settings_capability');

	// (Optional) Hide the ACF admin menu item.
	//if( ! $_SERVER['REMOTE_ADDR'] == '127.0.0.1' &&  ! $_SERVER['REMOTE_ADDR'] == '::1' ) // Don't hide the ACF Menu on local development machines so it's easier for developers to develop! :)
	if(strcmp( $_SERVER['REMOTE_ADDR'], '127.0.0.1' ) !== 0 && strcmp( $_SERVER['REMOTE_ADDR'], '::1' ) !== 0)		
		{
		add_filter('acf/settings/show_admin', 'my_acf_settings_show_admin');
		}
	function my_acf_settings_show_admin( $show_admin ) {
		return false;
	}

	if( function_exists('acf_add_options_page') ) {
		
		acf_add_options_page(array(
			'page_title' 	=> 'Theme General Settings',
			'menu_title'	=> 'Theme Settings',
			'menu_slug' 	=> 'theme-general-settings',
			'capability'	=> 'edit_posts',
			'redirect'		=> false
		));
	}
	
//Warn end users that find their way into the ACF settings GIU not to modify our Theme's ACF Field Groups (because they have the ACF plugin itself or another plugin that uses it that is firing later than our theme and overriding the "hide ACF admin" option or they hacked the URL to get at it without using the GUI)

	function uofi_theme_ACF_admin_notice()
	{
		//get the current screen
		$screen = get_current_screen();
		
		//Only output this warning on the ACF "Field Groups" screen of the dashboard
		if ( $screen->id !== 'edit-acf-field-group') return;
			 
		?>
	 
		<div class="notice notice-warning is-dismissible">
			<p><?php _e('<h2>WARNING</h2><p>Unless you are a theme developer working on the University of Illinois Theme, DO NOT make changes to the following field groups, or you risk breaking your site:<ul style="list-style: disc;  padding-left: 2rem;"><li>Theme General Settings</li><li>Theme Menu Adornments</li><li>Theme Options</li></ul><p><p>If you should decide to make changes anyway, and things break, you can restore the original values by downloading a fresh copy of the University of Illinois theme and uploading it over your current one. If you are a Publish.Illinois.Edu (PIE) user, contact consult@illinois.edu for help restoring these ACF Field Groups to their default state.</p>', 'textdomain') ?></p>
		</div>
	 
		<?php 
	}
	
	add_action( 'admin_notices', 'uofi_theme_ACF_admin_notice' );

/* Set up custom menu walker */

/**
 * Register Custom Navigation Walkers
 */
	function register_navwalker(){
		require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php'; // Navwalker for simple menu
		require_once get_template_directory() . '/class-wp-mega-menu-navwalker.php'; // Navwalker fore mega-menu 'lite'
	}
	add_action( 'after_setup_theme', 'register_navwalker' );


/* Style ACF admin (dashboard) menus */
	function my_acf_admin_head() {
		?>
		<style type="text/css">
			tr.acf-row:nth-child(even) .acf-row-handle.order, tr.acf-row:nth-child(even) .acf-row-handle.remove
				{
				background: #dcdcdc !important;
				}

			.menulink
			{
				display: flex;
			}
				
			.menuindent
			{
				display:flex;
			}

		</style>
		<?php
	}
	add_action('acf/input/admin_head', 'my_acf_admin_head');

	add_filter('acf/location/rule_types', 'acf_location_rules_types');

	function acf_location_rules_types($choices)
	{
		$choices['Menu']['menu_level'] = 'Menu Level';

		return $choices;
	}

	add_filter('acf/location/rule_values/menu_level', 'acf_location_rule_values_level');

	function acf_location_rule_values_level($choices)
	{
		$choices[0] = '0';
		$choices[1] = '1';
		$choices[2] = '2';
		$choices[3] = '3';
		$choices[4] = '4';
		$choices[5] = '5';
		$choices[6] = '6';
		$choices[7] = '7';
		$choices[8] = '8';
		$choices[9] = '9';
		$choices[10] = '10';
		
		return $choices;
	}

	add_filter('acf/location/rule_match/menu_level', 'acf_location_rule_match_level', 10, 4);
	function acf_location_rule_match_level($match, $rule, $options, $field_group)
	{
		if ($rule['operator'] == "==" && array_key_exists( 'nav_menu_item_depth', $options )) {
			$match = ($options['nav_menu_item_depth'] == $rule['value']);
		}

		return $match;
	}

	function menus_admin_body_class( $classes ) {
		
		$use_theme_menu =  get_field('use_theme_menu', 'option') ? get_field('use_theme_menu', 'option') : false; //Advanced Custom Fields function, get_field()

		if(!$use_theme_menu)
			{
			$classes .= ' hide_menu_adornments ';
			}
		else
			{
			$classes .= ' show_menu_adornments ';
			}
	 
		return $classes;
	}
	add_filter( 'admin_body_class', 'menus_admin_body_class' );


// Update CSS and JS within in Admin
	function admin_style() {

	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/bootstrap/bootstrap.css' );
	
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/bootstrap/bootstrap.js');
	
	wp_enqueue_style('admin-styles', get_template_directory_uri().'/css/admin.css');
	
	wp_enqueue_script( 'admin-js', get_template_directory_uri() . '/admin.js');
	
	}
	add_action('admin_enqueue_scripts', 'admin_style');

/* Core Block Tweaks */
//deregister built-in styles for blocks

function uofi_2020_remove_block_style() {
    // Register the block editor script.
    wp_register_script( 'remove-block-style', get_template_directory_uri() . '/js/remove-block-styles.js', [ 'wp-blocks', 'wp-edit-post' ],null );
    // register block editor script.
    register_block_type( 'uofi2020/remove-block-style', [
        'editor_script' => 'remove-block-style',
    ] );
}
add_action( 'init', 'uofi_2020_remove_block_style');


//add uofi button styles
function uofi_2020_add_block_styles() {
    // Register the block editor script.
    wp_enqueue_script( 'add-block-styles', get_template_directory_uri() . '/js/add-block-styles.js', [ 'wp-hooks', 'wp-blocks', 'wp-edit-post' ], '1.0.0', true );
    // register block editor script.
    register_block_type( 'uofi2020/add-block-styles', [
        'editor_script' => 'add-block-styles',
    ] );
}
add_action( 'enqueue_block_editor_assets', 'uofi_2020_add_block_styles');


add_theme_support( 'editor-color-palette', array(

array(
        'name' => __( 'White', 'themeLangDomain' ),
        'slug' => 'white',
        'color' => '#FFFFFF',
    ),
    array(
        'name' => __( 'Cloud', 'themeLangDomain' ),
        'slug' => 'il-cloud',
        'color' => '#F8FAFC',
    ),
    array(
        'name' => __( 'Cloud Variant 1', 'themeLangDomain' ),
        'slug' => 'il-cloud-1',
        'color' => '#E8E9EB',
    ),
    array(
        'name' => __( 'Cloud Variant 2', 'themeLangDomain' ),
        'slug' => 'il-cloud-2',
        'color' => '#DDDEDE',
    ),
    array(
        'name' => __( 'Cloud Variant 3', 'themeLangDomain' ),
        'slug' => 'il-cloud-3',
        'color' => '#D2D2D2',
    ),
    array(
        'name' => __( 'Black', 'themeLangDomain' ),
        'slug' => 'black',
        'color' => '#000000',
    ),
    array(
        'name' => __( 'Illini Orange', 'themeLangDomain' ),
        'slug' => 'il-orange',
        'color' => '#FF552E',
    ),
    array(
        'name' => __( 'Altgeld', 'themeLangDomain' ),
        'slug' => 'il-altgeld',
        'color' => '#DD3403',
	),
    array(
        'name' => __( 'Heritage Orange', 'themeLangDomain' ),
        'slug' => 'il-heritage-orange',
        'color' => '#F5821E',
    ),
    array(
        'name' => __( 'Heritage Orange Variant 1', 'themeLangDomain' ),
        'slug' => 'il-heritage-orange-1',
        'color' => '#E56E15',
    ),
    array(
        'name' => __( 'Heritage Orange Variant 2', 'themeLangDomain' ),
        'slug' => 'il-heritage-orange-2',
        'color' => '#CE5E11',
    ),
    array(
        'name' => __( 'Heritage Orange Variant 3', 'themeLangDomain' ),
        'slug' => 'il-heritage-orange-3',
        'color' => '#B74D04',
    ),
    array(
        'name' => __( 'Illini Blue', 'themeLangDomain' ),
        'slug' => 'il-blue',
        'color' => '#13294B',
    ),
    array(
        'name' => __( 'Alma Mater', 'themeLangDomain' ),
        'slug' => 'il-alma-mater',
        'color' => '#1E3877',
    ),
    array(
        'name' => __( 'Alma Mater Variant 1', 'themeLangDomain' ),
        'slug' => 'il-alma-mater-1',
        'color' => '#4D69A0',
    ),
    array(
        'name' => __( 'Alma Mater Variant 2', 'themeLangDomain' ),
        'slug' => 'il-alma-mater-2',
        'color' => '#849BC1',
    ),
    array(
        'name' => __( 'Alma Mater Variant 3', 'themeLangDomain' ),
        'slug' => 'il-alma-mater-3',
        'color' => '#AFC7DB',
    ),
    array(
        'name' => __( 'Industrial Blue', 'themeLangDomain' ),
        'slug' => 'il-industrial-blue',
        'color' => '#1D58A7',
    ),
    array(
        'name' => __( 'Industrial Blue Variant 1', 'themeLangDomain' ),
        'slug' => 'il-industrial-blue-1',
        'color' => '#5783BC',
    ),
    array(
        'name' => __( 'Industrial Blue Variant 2', 'themeLangDomain' ),
        'slug' => 'il-industrial-blue-2',
        'color' => '#90AED5',
    ),
    array(
        'name' => __( 'Industrial Blue Variant 3', 'themeLangDomain' ),
        'slug' => 'il-industrial-blue-3',
        'color' => '#CAD9EF',
    ),
    array(
        'name' => __( 'Arches Blue', 'themeLangDomain' ),
        'slug' => 'il-arches-blue',
        'color' => '#009FD4',
    ),
    array(
        'name' => __( 'Arches Blue Variant 1', 'themeLangDomain' ),
        'slug' => 'il-arches-blue-1',
        'color' => '#7FC3E1',
    ),
    array(
        'name' => __( 'Arches Blue Variant 2', 'themeLangDomain' ),
        'slug' => 'il-arches-blue-2',
        'color' => '#A6D7EB',
    ),
    array(
        'name' => __( 'Arches Blue Variant 3', 'themeLangDomain' ),
        'slug' => 'il-arches-blue-3',
        'color' => '#D2EBF5',
    )

) );


/* Add the wide and full alignment/width options for gutenberg block elements */

add_theme_support( 'align-wide' );

/* set a wrapper around the default styled/aligned image element to use for styling, since core/image comes with no alignment by default, which, just for the figure/image element, fails to output a parent <div> element for styling, as of WP Core Aug 21, 2021, though there are active developer threads on wordpress.org asking to have this changed, so we may not need this eventually */

function uofi_wrap_image_block( $block_content, $block ) {
	
	$do_not_il_format_blocks = array('acf/uofi-hero-block', 'core/columns', 'core/column', 'core/group');
	$user_no_il_format_block_fields = 	get_field('no_il_format', 'options') ? get_field('no_il_format', 'options') : null; //These are the block names we let end user specify in the Theme Settings > Advanced Settings to exclude from wrapping
	$user_no_il_format_blocks = array();
	if($user_no_il_format_block_fields)
		{
		foreach($user_no_il_format_block_fields as $user_no_il_format_block_field)
			{
			$user_no_il_format_blocks[] = $user_no_il_format_block_field['no_il_format_block'];
			}
		}
		
	$il_formatted_class = "il-formatted";
	
	if( in_array( $block['blockName'], $do_not_il_format_blocks) || in_array( $block['blockName'], $user_no_il_format_blocks) )
		{
		$il_formatted_class = null;	
		}

	//Uncomment this code block if you need to peak at what the slug names of problematic blocks that need not to be wrapped are --rslater
	/*
	echo("\r\n");
	var_dump($block);
	echo("\r\n");
	*/
	
	$no_wrap_block_names = array('core/column', 'core/button', 'uagb/column'); //These are blocks we know get messed up if wrapped in a parent div becuase it messes with slector targetting or inline styles on that blocks HTML element, usually a div
	$user_no_wrap_block_fields = get_field('no_wrap_blocks', 'options') ? get_field('no_wrap_blocks', 'options') : null; //These are the block names we let end user specify in the Theme Settings > Advanced Settings to exclude from wrapping
	$user_no_wrap_blocks = array();
	if($user_no_wrap_block_fields)
		{
		foreach($user_no_wrap_block_fields as $user_no_wrap_block_field)
			{
			$user_no_wrap_blocks[] = $user_no_wrap_block_field['no_wrapper_block'];
			}
		}
	$block_class = array_key_exists( 'className', $block['attrs']) ? $block['attrs']['className'] : null;
	$block_classes = array();
	if ( $block_class  )
		{
		$block_classes = explode(' ', $block_class);
		}
	
	$return = '';
		
	if (  in_array($block['blockName'], $no_wrap_block_names, true ) != 1 && in_array($block['blockName'], $user_no_wrap_blocks, true ) != 1)
		{
		if( $block['blockName'] ==  'core/image' && ( !array_key_exists( 'align', $block['attrs'] )  || !array_key_exists( 'align', $block['attrs'] ) ) )
			{
			$block_content = '<div class="wp-block-image no-editor-align">' . $block_content . '</div>';
			}

		if( $block['blockName'] ==  'core/media-text' )
			{
			$block_content = '<div class="wp-media-text-wrapper">' . $block_content . '</div>';
			}
			
		if( $block['blockName'] ==  'core/html')	
			{
			$toothpick = '/class=(("|\')|("|\')([^"\']*)\s)alignfull(("|\')|\s([^"\']*)("|\'))/i';
			$alignfull = '';
			if (preg_match( $toothpick, $block_content))
				{
				$alignfull = 'alignfull';	
				}
			$return .= '<div class="uofi-default-block custom_html_block ' . $alignfull .'">';
			$return .= $block_content;
			$return .= '</div>';					
			}
		elseif ( ( array_key_exists( 'attrs', $block ) && array_key_exists( 'align', $block['attrs']) && $block['attrs']['align'] == 'full' ) || ( in_array( 'alignfull', $block_classes, true ) == 1 ) )
			{
			$return .= '<div class="uofi-default-block alignfull ' . $il_formatted_class . '">';
			$return .= $block_content;
			$return .= '</div>';	
			}
		else
			{
			$return  .= '<div class="uofi-default-block ' . $il_formatted_class . '">';
			$return .= $block_content;
			$return .= '</div>';	
			}
		}
		else
		{
		$return = $block_content;
		}
		
	return $return;
}

add_filter( 'render_block', 'uofi_wrap_image_block', 10, 2 );

/* Add a class to the body tag to indicate is the page/post uses the sidebar or not */

//Page Slug Body Class
function set_sidebar_class_on_body( $classes )
{
	global $post;
	
	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page = false;
	$suppress_sidebar = $suppress_sidebar_site_wide;
	
	if( is_object($post) ) 
		{
		$show_sidebar_this_page =  get_field('suppress_sidebar', $post->ID) ? get_field('suppress_sidebar', $post->ID) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
		}
		
	if($show_sidebar_this_page != 0) 
		{
		$suppress_sidebar = $show_sidebar_this_page - 1;
		}
	
	if ( is_category() || is_search() )
		{
		if ( ! $suppress_sidebar_site_wide )
			{
			$classes[] = 'no-sidebar';
			}
		else
			{
			$classes[] = 'has-sidebar';
			}	
		}
	elseif ( isset( $post ) )
		{
		if ( ! $suppress_sidebar )
			{
			$classes[] = 'no-sidebar';
			}
		else
			{
			$classes[] = 'has-sidebar';
			}	
		}
		else
		{
		if ( ! $suppress_sidebar_site_wide )
			{
			$classes[] = 'no-sidebar';
			}
		else
			{
			$classes[] = 'has-sidebar';
			}				
		}
	return $classes;
}
add_filter( 'body_class', 'set_sidebar_class_on_body' );


//Plug WP core security flaw that allows public access to a list of all users who have ever authored a public page or post, ever. Instead, require that only logged on users can access this feature--rslater, 3-9-2021
add_filter( 'rest_api_init', 'rest_only_for_authorized_users', 99 );
function rest_only_for_authorized_users($wp_rest_server){
    if ( !is_user_logged_in() ) {
        wp_die('You must be logged in to use this feature','Please Log In',403);
    }
}


/* Blocks */

//Add Custom Gutenberg Block Category: Pieces of PIE, pie-blocks

	function uofi_block_category( $categories, $post ) {
		return array_merge(
			$categories,
			array(
				array(
					'slug' => 'uofi-blocks',
					'title' => __( 'Illinois Theme', 'pie-blocks' ),
				),
			)
		);
	}
	add_filter( 'block_categories', 'uofi_block_category', 10, 2);

// Add Blocks

		// Hero Block
		acf_register_block_type(array(
			'name'				=> 'uofi-hero-block' ,
			'title'				=> __('Hero'),
			'description'		=> __('Place text/links/buttons/etc. over a responsive background image.'),
			'render_template'   => 'template-parts/blocks/hero/hero.php',
			'supports'			=> array('align' => array( 'full', 'wide' ), 'jsx' => true), //This is a full-viewport-width block, always, so disable user controls for alignment. jsx true is necessaru to use the javascript template to render the default/placeholder first card in the deck, //This is a full-viewport-width block, always, so disable user controls for alignment
			'category'			=> 'uofi-blocks',
			'icon'				=> 'slides',
			'keywords'			=> array( 'hero', 'acf')
		));
		
		// Card Block
		acf_register_block_type(array(
			'name'				=> 'uofi-card-block' ,
			'title'				=> __('Clickable Card'),
			'description'		=> __('Create cards with image on top and text below.'),
			'render_template'   => 'template-parts/blocks/card/card.php',
			'supports'			=> array('align' => true),
			'category'			=> 'uofi-blocks',
			'icon'				=> 'id-alt',
			'keywords'			=> array( 'card', 'acf')
		));
		
		// Card Deck
		acf_register_block_type(array(
			'name'				=> 'uofi-card-deck-block' ,
			'title'				=> __('Clickable Card Deck'),
			'description'		=> __('Create Card Deck to place cards within, which forces all cards in the deck to have euqal hieghts and widths.'),
			'render_template'   => 'template-parts/blocks/card-deck/card-deck.php',
			'supports'			=> array('align' => array( 'full', 'wide' ), 'jsx' => true), //This is a full-viewport-width block, always, so disable user controls for alignment. jsx true is necessaru to use the javascript template to render the default/placeholder first card in the deck
			'category'			=> 'uofi-blocks',
			'icon'				=> 'admin-page',
			'keywords'			=> array( 'deck', 'card', 'card deck', 'acf')
		));
		
		//Accordion Section
		acf_register_block_type(array(
			'name'				=> 'uofi-accordion-section-block' ,
			'title'				=> __('Accordion Section'),
			'description'		=> __('A single "toggle to open/close" section.'),
			'render_template'   => 'template-parts/blocks/accordion-section/accordion-section.php',
			'supports'			=> array('align' => true, 'jsx' => true), //This is a full-viewport-width block, always, so disable user controls for alignment. jsx true is necessaru to use the javascript template to render the default/placeholder first card in the deck 
			'category'			=> 'uofi-blocks',
			'icon'				=> 'list-view',
			'keywords'			=> array( 'accordion', 'accordion section', 'acf')
		));
		
		//Accordion Deck
		acf_register_block_type(array(
			'name'				=> 'uofi-accordion-deck-block' ,
			'title'				=> __('Accordion Deck'),
			'description'		=> __('A container to hold multiple "toggle to open/close" Accodrian Section Blocks. Optionally allows only one accordian section to be opened at a time.'),
			'render_template'   => 'template-parts/blocks/accordion-deck/accordion-deck.php',
			'supports'			=> array('align' => true, 'jsx' => true), //This is a full-viewport-width block, always, so disable user controls for alignment. jsx true is necessaru to use the javascript template to render the default/placeholder first card in the deck 
			'category'			=> 'uofi-blocks',
			'icon'				=> 'list-view',
			'keywords'			=> array( 'accordion', 'accordion deck', 'acf')
		));
		
/* Adjust Core Blocks */
/**
 * Gutenberg scripts and styles
 * @link https://www.billerickson.net/block-styles-in-gutenberg/
 */
function be_gutenberg_scripts() {

	wp_enqueue_script(
		'be-editor', 
		get_stylesheet_directory_uri() . '/js/editor.js', 
		array( 'wp-blocks', 'wp-dom' ), 
		false,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'be_gutenberg_scripts' );
