<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package University_of_Illinois_2020
 */

?>
<?php
$suppress_sidebar_this_page =  get_field('suppress_page_title') ? get_field('suppress_page_title') : false; //Advanced Custom Fields function, get_field() 
$hide_title =  $suppress_sidebar_this_page ? 'screen-reader-text' : '';
$featured_image_settings =  get_field('featured_image_options') ? get_field('featured_image_options') : null; // Advanced Custom Fields function, get_field()
	if($featured_image_settings)
		{
		$featured_image_display = $featured_image_settings['display_style'] ? $featured_image_settings['display_style'] : 'page' ;
		$featured_image_display_height = has_post_thumbnail($post->ID) ? wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false )[1] . 'px' : 'auto' ; 
		}
	else
		{
		$featured_image_display = 'left' ; //The default is left for historical reasons. Before the alignment was optional, in version <= 1.1.3, it was always left aligned -rslater 9-14-2021
		}

$max_width = "870";

	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
	$show_sidebar = $suppress_sidebar_site_wide;
	if($show_sidebar_this_page != 0) 
		{
		$show_sidebar = $show_sidebar_this_page - 1;
		}
		
if (!$show_sidebar)
	{
	$max_width = "1200";	
	}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<?php
		if( has_post_thumbnail() && ($featured_image_display == 'left' || $featured_image_display == 'right') )
			{
			?>		
			<div class="uofi-featured-image">
				<div class="wp-block-image ">
				<figure class="align<?= $featured_image_display ?>">
						<img loading="lazy" src="<?= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false )[0]; ?>" alt="<?= get_post_meta( get_post_thumbnail_id(), '_wp_attachment_image_alt', true ) ? get_post_meta( get_post_thumbnail_id(), '_wp_attachment_image_alt', true ) : 'Site Header Image' ?>" class="wp-image-50"/>
				</figure></div>
			</div>

			<?php
			} 
		?>

	<header class="entry-header il-formatted">
		<?php
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title">', '</h1>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				uofi_2020_posted_on();
				uofi_2020_posted_by();
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->
	
	<div class="entry-content">	
		<?php
		if ( is_singular() ) :
		
			the_content(
								sprintf(
									wp_kses(
										/* translators: %s: Name of current post. Only visible to screen readers */
										__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'uofi-2020' ),
										array(
											'span' => array(
												'class' => array(),
											),
										)
									),
									wp_kses_post( get_the_title() )
								)
							);

		else :
		
			the_excerpt(
								sprintf(
									wp_kses(
										/* translators: %s: Name of current post. Only visible to screen readers */
										__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'uofi-2020' ),
										array(
											'span' => array(
												'class' => array(),
											),
										)
									),
									wp_kses_post( get_the_title() )
								)
							);
		endif;
		
		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'uofi-2020' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php uofi_2020_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
