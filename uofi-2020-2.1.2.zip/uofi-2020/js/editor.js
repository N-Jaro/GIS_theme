wp.domReady( () => {

	//tables
	wp.blocks.unregisterBlockStyle(
			'core/table',
			[ 'regular', 'stripes']
		);	
		
	wp.blocks.registerBlockStyle( 'core/table', [ 
		{
			name: 'default',
			label: 'Default',
			isDefault: true,
		},
		{
			name: 'simple',
			label: 'U of I Simple',
		},
		{
			name: 'no-borders',
			label: 'No Borders',
		}
	]);

} );