<?php
/**
 * The searchform.php template.
 *
 * Used any time that get_search_form() is called.
  */
  
$rand =  bin2hex(openssl_random_pseudo_bytes(10));
?>
<div class="site_search_form_container input-group">
	<form role="search" aria-label="Site Search" method="get" class="search-form flex-grow-1" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<div class="input_wrapper d-flex">
			<div class="flex-grow-1 d-flex">
				<label for="search_form_input_<?=$rand?>" class="screen-reader-text">Search the site</label>
				<input type="search" id="search_form_input_<?=$rand?>" class="search-field flex-grow-1" placeholder="Search this site" value="<?php echo get_search_query(); ?>" name="s" />
			</div>
			<div class="d-flex flex-column justify-content-center">
				<span class="input-group-btn">
					<button type="submit" class="search-submit" value=""><i class="fa fa-search"></i><span class="screen-reader-text">Search</span></button>
				</span>
			</div>
		</div>
	</form>
</div>