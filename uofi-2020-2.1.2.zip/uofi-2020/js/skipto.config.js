var SkipToConfig =  {
  'settings': {
     'skipTo': {
         landmarks: 'main, [role="main"], [role="search"], nav, aside, region, section',
         headings: 'main h1, main h2, main h3, main h4, main h5',
         headingGroupLabel:  'Headings',
         displayOption: 'popup',
         colorTheme: 'illinois',
				 customClass: 'uofi2020-above-admin-menu',
    }
  }
};
