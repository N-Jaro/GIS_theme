<?php

/**
 * Hero Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'uofi-card-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'uofi uofi-card';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and assign defaults.
$width = get_field('width') ?: 350;
$image = get_field('image') ?:  get_template_directory_uri() . '/template-parts/blocks/card/your-image-goes-here.jpg' ;
$title = get_field('title') ?: null;
	// function_exists('get_current_screen') generally only returns true on admin pages, not preview/view pages, thus we use it to tell "user is editing the content"
	if( !$title && function_exists('get_current_screen') == 1  ) { $title = 'Edit this in Edit Mode <span class="dashicon dashicons dashicons-edit" style="display: inline; vertical-align: -0.05em; font-size: .8em;"></span>  or Block Settings Panel <span style="display: inline-flex"><svg width="0.8em" height="0.8em" style="display:inline-flex; filter: drop-shadow(0.04em 0.04em 0.08em black);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" role="img" aria-hidden="true" focusable="false"><path fill="#FFFFFF" fill-rule="evenodd" d="M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" clip-rule="evenodd"></path></svg></span>';}
$text = get_field('text') ?: null;
	if( !$text && function_exists('get_current_screen') == 1  ) { $text = '<div class="freeform"><p>Edit this in Edit Mode  (click this and then the pencil icon above <span class="dashicon dashicons dashicons-edit" style="display:inline-flex; vertical-align: -0.15rem;"></span>)  or in the Block Settings Panel (to the right, which can be toggled open with the gear icon <span style="display: inline-flex;"><svg width="0.8em" height="0.8em" style="filter: drop-shadow(0.04em 0.04em 0.08em black);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" role="img" aria-hidden="true" focusable="false"><path fill="#ffffff" fill-rule="evenodd" d="M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" clip-rule="evenodd"></path></svg></span>)</p></div>';}; 
$link = get_field('link') ?: null;
?>
<div id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?> " style="width: <?= $width ?>px; max-width: 100%;">
<il-clickable-card  src="<?= $image ?>" <?php if ( function_exists('get_current_screen') !== 1 && $link ) { echo('href="' . $link . '"' ); } ?>>
<h3 slot="header"><?= $title ?></h3>
<p><?= $text  ?></p>
</il-clickable-card>
</div>













