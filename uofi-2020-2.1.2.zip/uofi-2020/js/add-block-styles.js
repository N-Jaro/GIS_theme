wp.blocks.registerBlockStyle('core/button',{
	name: 'button-primary',
	label: 'Primary',
	isDefault: true
});

wp.blocks.registerBlockStyle('core/button',{
	name: 'button-secondary',
	label: 'Secondary'
});

wp.blocks.registerBlockStyle('core/button',{
	name: 'button-illini-blue-solid',
	label: 'Illini Blue Solid'
});

wp.blocks.registerBlockStyle('core/button',{
	name: 'button-illini-orange-solid',
	label: 'Illini Orange Solid'
});

wp.domReady( () => {
	
	wp.blocks.registerBlockStyle(
		'core/cover',
		[
			{
				name: 'black-text-shadow',
				label: 'Black Text Shadow',
				isDefault: true,
			},
			{
				name: 'white-text-shadow',
				label: 'White Text Shadow',
			}
		]
	);	

	wp.blocks.registerBlockStyle(
		'core/media-text',
		[
			{
				name: 'primary',
				label: 'Blue/Orange Link Color',
				isDefault: true,
			},
			{
				name: 'secondary',
				label: 'Orange/White Link Color',
			},
			{
				name: 'tertiary',
				label: 'Blue/White Link Color',
			},
			{
				name: 'quaternary',
				label: 'Orange/Black Link Color',
			}
		]
	);	
	
} );