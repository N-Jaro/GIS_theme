wp.domReady(() => {
        wp.blocks.unregisterBlockStyle( 'core/button', 'fill' );
        wp.blocks.unregisterBlockStyle( 'core/button', 'outline' );
        wp.blocks.unregisterBlockStyle( 'core/button', 'default' );
});
