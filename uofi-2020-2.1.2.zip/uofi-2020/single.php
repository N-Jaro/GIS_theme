<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package University_of_Illinois_2020
 */

get_header();
?>
<?php
	$featured_image_settings =  get_field('featured_image_options') ? get_field('featured_image_options') : null; // Advanced Custom Fields function, get_field()
	if($featured_image_settings)
		{
		$featured_image_display = $featured_image_settings['display_style'] ? $featured_image_settings['display_style'] : 'page' ;
		$featured_image_display_height = has_post_thumbnail($post->ID) ? wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false )[1] . 'px' : 'auto' ; 
		}
	else
		{
		$featured_image_display = 'left' ; //The default is left for historical reasons. Before the alignment was optional, in version <= 1.1.3, it was always left aligned -rslater 9-14-2021
		}
			
	if($featured_image_display == "page")
		{
			$featured_image_display_width = 'max-width: 1140px;';
		}
	$suppress_sidebar_site_wide =  get_field('sidebar_default', 'options') ? get_field('sidebar_default', 'options') : false; //Advanced Custom Fields function, get_field() = TRUE || FALSE
	$show_sidebar_this_page =  get_field('suppress_sidebar', get_queried_object_id()) ? get_field('suppress_sidebar', get_queried_object_id()) : 0; //Advanced Custom Fields function, get_field()  = 0 Use Site Default || 1 : Hide Sidebar || 2 : Show Sidebar
	$show_sidebar = $suppress_sidebar_site_wide;
	if($show_sidebar_this_page != 0) 
		{
		$show_sidebar = $show_sidebar_this_page - 1;
		}
?>
	<?php	if( $featured_image_display == 'page' ||  $featured_image_display =="screen") {	?>
		<div class="hero-featured-image " style="background-image: url(<?= wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full', false )[0]; ?>); height: <?= $featured_image_display_height ?> ; <?= $featured_image_display_width ?>">
		</div>
	<?php } ?>
	<div id="primary_secondary_wrapper" class="d-flex flex-md-row flex-column justify-content-center ">
		<main id="primary" class="site-main <?php if (! $show_sidebar) { echo('flex-grow-1'); } ?>" aria-label="Document Content">
			<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );

			the_post_navigation(
				array(
					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'uofi-2020' ) . '</span> <span class="nav-title">%title</span>',
					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'uofi-2020' ) . '</span> <span class="nav-title">%title</span>',
					'aria_label' => 'Previous/Next Post'
				)
			);

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
		<?php
		get_sidebar();
		?>
	</div>
<?php
get_footer();
?>
